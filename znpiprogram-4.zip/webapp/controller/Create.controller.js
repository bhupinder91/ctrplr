sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (Controller, DateFormat, MessageToast, MessageBox) {
	"use strict";

	return Controller.extend("NPI.NPI_UI5.controller.Create", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf NPI.NPI_UI5.view.Create
		 */
		onInit: function () {
			this.oUpdateModel = this.getOwnerComponent().getModel();
		},
		onSelectEng: function (oRadioButton) {
			var selctedIndex = oRadioButton.getParameter("selectedIndex");
			if (selctedIndex === 0) {
				this.getView().getModel("isVisible").setProperty("/visiblilty1", true);
				this.getView().getModel("isVisible").setProperty("/visiblilty2", false);
			} else {
				this.getView().getModel("isVisible").setProperty("/visiblilty1", false);
				this.getView().getModel("isVisible").setProperty("/visiblilty2", true);
			}
		},
		/*	handleUserInput: function (oEvent) {
				var sUserInput = oEvent.getParameter("value");
				var oInputControl = oEvent.getSource();
				if (sUserInput) {
					oInputControl.setValueState(sap.ui.core.ValueState.Success);
				} else {
					oInputControl.setValueState(sap.ui.core.ValueState.Error);
				}
			},*/
		onPressSave: function () {
			var sPrgm_id = this.getView().byId("id_programid_crt").getValue();
			var sSeril_no = this.getView().byId("id_sno_crt").getValue();
			if (sPrgm_id === "" || sSeril_no === "") {

				if (sPrgm_id === "" && sSeril_no === "") {
					this.getView().byId("id_programid_crt").setValueState(sap.ui.core.ValueState.Error);
					this.getView().byId("id_sno_crt").setValueState(sap.ui.core.ValueState.Error);
				} else {
					if (sPrgm_id !== "") {
						this.getView().byId("id_programid_crt").setValueState(sap.ui.core.ValueState.Success);
					}
					if (sSeril_no !== "") {
						this.getView().byId("id_sno_crt").setValueState(sap.ui.core.ValueState.Success);
					}
				}
			} else {
				var nepar = this.getView().byId("id_nepar").getSelected();
				var sNeparFlag;
				if (nepar === true) {
					sNeparFlag = "X";
				} else {
					sNeparFlag = "";
				}
				var oNewData = {
					"ProgramId": this.getView().byId("id_programid_crt").getValue(),
					"SerialNumber": this.getView().byId("id_sno_crt").getValue(),
					"NpiDescription": this.getView().byId("id_descr_crt").getValue(),
					"SalesModel": this.getView().byId("id_sales_crt").getValue(),
					"ProductFamily": this.getView().byId("id_prod_fam_crt").getValue(),
					"IndustyType": this.getView().byId("id_ind_typ_crt").getValue(),
					"ProgramType": this.getView().byId("id_pgm_typ_crt").getValue(),
					"EmissionProgram": this.getView().byId("id_emission_crt").getValue(),
					"Gw6Date": this.getView().byId("id_gw6date_crt").getDateValue(),
					"NpiManager": this.getView().byId("id_npi_mng_crt").getValue(),
					"NeparFlag": sNeparFlag,
					"PPM": this.getView().byId("id_ppm_combo_crt").getSelectedKey(),
					"CapSalesModel": this.getView().byId("id_cap_sales_crt").getValue(),
					"Status": this.getView().byId("id_programid_crt").getValue(),
					"FirstShipDate": this.getView().byId("id_first_ship_crt").getDateValue(),
					"ProjectToDate": this.getView().byId("id_prj_date_crt").getDateValue(),
					"BlitzDate": this.getView().byId("id_blitz_date_crt").getDateValue(),
					"BlitzStatus": this.getView().byId("id_blitz_stat_crt").getValue(),
					"EngModel": this.getView().byId("id_eng_mod_crt").getValue(),
					"Comments": this.getView().byId("id_comments_crt").getValue()
						/*	"NPIEngModelSet": [{
									"ProgramId": "TEST1",
									"EngModel": "ENG4",
									"Descr": "test"
								}]*/
						/*										"to_part": [{
																	"part_number": "test",
																	"createdby": "test1"
																}]*/
				};
				this.oUpdateModel.create("/NPIProgramSet", oNewData, {
					success: function (oData) {
						/*sap.m.MessageBox.success(this.getView().getModel("i18n").getResourceBundle().getText("updatesuccessText"));*/
						//	sap.m.MessageBox.success("updatesuccessTextcreate");
						MessageToast.show("Successfully created new item");
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("Main", true);
						//	this._setViewBusy(false);
					}.bind(this),
					error: function (err) {
						//	sap.m.MessageBox.error("updateErrorText");
						MessageBox.error("updateErrorText");
						//	this._setViewBusy(false);
					}
				});
			}

			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf NPI.NPI_UI5.view.Create
			 */
			//	onBeforeRendering: function() {
			//
			//	},

			/**
			 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 * @memberOf NPI.NPI_UI5.view.Create
			 */
			//	onAfterRendering: function() {
			//
			//	},

			/**
			 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
			 * @memberOf NPI.NPI_UI5.view.Create
			 */
			//	onExit: function() {
			//
			//	}
		}
	});

});