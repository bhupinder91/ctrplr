sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("NPI.NPI_UI5.controller.Main", {
		onInit: function () {
			this.oUpdateModel = this.getOwnerComponent().getModel();
		},
		onItemPress: function (oEvent) {
			this.getView().getModel("isEditable").setProperty("/editable", false);
			this.getView().getModel("isEditable").setProperty("/submit", false);
			this.oUpdateModel.refresh(true);
			var path = oEvent.getParameter("listItem").getBindingContext().getPath();
			var selectedRow = this.byId("smartTable").getModel().getProperty(path);
			var sProgramId = selectedRow.ProgramId;
			var sSerialNumber = selectedRow.SerialNumber;
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Detail", {
				"ProgramId": sProgramId,
				"SerialNumber": sSerialNumber
			});
		},

		onPressCreate: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Create");
			/*
						var oHeaderData = {};
						this.oUpdateModel.create("/NPIProgramSet", oHeaderData, {
							success: function (oData) {
								sap.m.MessageBox.success(this.getView().getModel("i18n").getResourceBundle().getText("updatesuccessText"));
								this._setViewBusy(false);
							}.bind(this),
							error: function (err) {
								sap.m.MessageBox.error(this.getView().getModel("i18n").getResourceBundle().getText("updateErrorText"));
								this._setViewBusy(false);
							}
						});*/
		}

	});
});