sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/routing/History", "sap/m/MessageToast", "sap/m/MessageBox",
	"sap/ui/core/Fragment"
], function (Controller,
	History,
	MessageToast, MessageBox, Fragment) {
	"use strict";
	var engLocalJsonModel;
	var salesLocalJsonModel;
	var aPartsDataNewRow = [];
	var aTableDataNewRow = [];
//	var aTableData = [];
//var aPartsData = [];
	var aTableDataSelected = [];
	return Controller.extend("NPI.NPI_UI5.controller.Detail", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf NPI.NPI_UI5.view.Detail
		 */
		onInit: function () {
			this.oUpdateModel = this.getOwnerComponent().getModel();
			engLocalJsonModel = new sap.ui.model.json.JSONModel();
			salesLocalJsonModel = new sap.ui.model.json.JSONModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("Detail")
				.attachMatched(this.onRouteMatched, this);
			this.getView().byId("id_EngTable").setModel(engLocalJsonModel, "NPIEngModelS");
			this.getView().byId("id_PartTable").setModel(salesLocalJsonModel, "NPIPartNumS");
		},
		onRouteMatched: function (oEvent) {
			var sProgramID = oEvent.getParameter("arguments").ProgramId;
			var serialNum = oEvent.getParameter("arguments").SerialNumber;
			this.getView().bindElement(
				"/NPIProgramSet(ProgramId='" + sProgramID + "',SerialNumber='" + serialNum + "')"
			);
			this.oUpdateModel.read("/NPIProgramSet(ProgramId='" + sProgramID + "',SerialNumber='" + serialNum + "')/NPIEngModelSet", {
				success: function (oData) {
					var aTableData = [];
					var engData = oData.results;
					for (var i = 0; i < engData.length; i++) {
						var obj = {
							"ProgramId": engData[i].ProgramId,
							"EngModel": engData[i].EngModel,
							"Descr": engData[i].Descr
						};
						aTableData.push(obj);
					}
					aTableDataNewRow =aTableData;
					engLocalJsonModel.setData(aTableData);
				},
				error: function (err) {
					MessageBox.error("error");
				}
			});
			this.oUpdateModel.read("/NPIProgramSet(ProgramId='" + sProgramID + "',SerialNumber='" + serialNum + "')/NPIPartNumSet", {
				success: function (oData) {
				var 	aPartsData =[];
					salesLocalJsonModel.setData(oData.results);
					var PartsData = oData.results;
					for (var i = 0; i < PartsData.length; i++) {
						var obj = {
							"Descr": PartsData[i].Descr,
							"PartNumber": PartsData[i].PartNumber
						};
						aPartsData.push(obj);
					}
					aPartsDataNewRow = aPartsData;
					salesLocalJsonModel.setData(aPartsData);
				},
				error: function (err) {
					MessageBox.error("error");
				}
			});
		},
		onSelectEng: function (oRadioButton) {
			var selctedIndex = oRadioButton.getParameter("selectedIndex");
			if (selctedIndex === 0) {
				this.getView().getModel("isVisible").setProperty("/visiblilty1", true);
				this.getView().getModel("isVisible").setProperty("/visiblilty2", false);
			} else {
				this.getView().getModel("isVisible").setProperty("/visiblilty1", false);
				this.getView().getModel("isVisible").setProperty("/visiblilty2", true);
			}
		},
		onSelectionChange: function (oEvent) {
			var sSelectedValue = oEvent.getParameters("selectedKey").value;
			if (sSelectedValue === "Yes") {
				this.getView().getModel("isVisible").setProperty("/visiblilty1", true);
				this.getView().getModel("isVisible").setProperty("/visiblilty2", false);
			} else {
				this.getView().getModel("isVisible").setProperty("/visiblilty1", false);
				this.getView().getModel("isVisible").setProperty("/visiblilty2", true);
			}
		},
		//functionality for edit button
		onEdit: function () {
			this.getView().getModel("isEditable").setProperty("/submit", true);
			this.getView().getModel("isEditable").setProperty("/editable", true);
		},
		onCancel: function (oEvent) {
			var oButton = oEvent.getSource();
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("NPI.NPI_UI5.fragment.Popover", this);
				this.getView().addDependent(this._oPopover);
				this._oPopover.openBy(oButton);
			} else {
				this._oPopover.openBy(oButton);
			}
		},
		onPressDiscard: function () {
			this._oPopover.close();
			this.oUpdateModel.refresh(true);
			this.getView().getModel("isEditable").setProperty("/editable", false);
			this.getView().getModel("isEditable").setProperty("/submit", false);
		},
		onDataCreationEngModel: function (oEvent) {
			var oNewData = {
				"ProgramId": "",
				"EngModel": "",
				"Descr": ""
			};
			aTableDataNewRow.push(oNewData);
			engLocalJsonModel.setData(aTableDataNewRow);
			this.getView().byId("id_EngTable").setModel(engLocalJsonModel, "NPIEngModelS");
		},
		onDeleteRowEngModel: function () {
			var arrTableData = this.getView().byId("id_EngTable").getModel("NPIEngModelS").getData();
			var arrSelectedIndices = this.getView().byId("id_EngTable").getSelectedContextPaths();
			for (var i = 0; i < arrSelectedIndices.length; i++) {
				var objSelectedData = arrSelectedIndices[i].split('/')[1];
				arrTableData.splice(objSelectedData, 1);
			}
			engLocalJsonModel.setData(arrTableData);
			this.getView().byId("id_EngTable").setModel(engLocalJsonModel, "NPIEngModelS");
		},
		onDataCreationSalesModel: function (oEvent) {
			var oNewData1 = {
				"Descr": "",
				"PartNumber": ""
			};
			aPartsDataNewRow.push(oNewData1);
			salesLocalJsonModel.setData(aPartsDataNewRow);
			this.getView().byId("id_PartTable").setModel(salesLocalJsonModel, "NPIPartNumS");
		},
		onDeleteRowPartsModel: function () {
			var arrTableData = this.getView().byId("id_PartTable").getModel("NPIPartNumS").getData();
			var arrSelectedIndices = this.getView().byId("id_PartTable").getSelectedContextPaths();
			for (var i = 0; i < arrSelectedIndices.length; i++) {
				var objSelectedData = arrSelectedIndices[i].split('/')[1];
				arrTableData.splice(objSelectedData, 1);
			}
			salesLocalJsonModel.setData(arrTableData);
			this.getView().byId("id_PartTable").setModel(salesLocalJsonModel, "NPIPartNumS");

		},
		onPressSubmit: function () {

			var updatedEngtableData = this.getView().byId("id_EngTable").getModel("NPIEngModelS").getData();
			var updatedPartstableData = this.getView().byId("id_PartTable").getModel("NPIPartNumS").getData();
			var pgmid = this.getView().byId("id_programid").getValue();
			var sno = this.getView().byId("id_sno").getValue();
			var nepar = this.getView().byId("id_nepar").getSelected();
			var sNeparFlag;
			if (nepar === true) {
				sNeparFlag = "X";
			} else {
				sNeparFlag = "";
			}
			var oHeaderData = {
				"ProgramId": this.getView().byId("id_programid").getValue(),
				"SerialNumber": this.getView().byId("id_sno").getValue(),
				"NpiDescription": this.getView().byId("id_descr").getValue(),
				"SalesModel": this.getView().byId("id_sales").getValue(),
				"ProductFamily": this.getView().byId("id_prod_fam").getValue(),
				"IndustyType": this.getView().byId("id_programid").getValue(),
				"ProgramType": this.getView().byId("id_programid").getValue(),
				"EmissionProgram": this.getView().byId("id_emission").getValue(),
				"Gw6Date": this.getView().byId("id_gw6date").getDateValue(),
				"NpiManager": this.getView().byId("id_npi_mng").getValue(),
				"NeparFlag": sNeparFlag,
				"PPM": this.getView().byId("id_ppm_combo").getSelectedKey(),
				"CapSalesModel": this.getView().byId("id_cap_sales").getValue(),
				"Status": this.getView().byId("id_programid").getValue(),
				"FirstShipDate": this.getView().byId("id_first_ship").getDateValue(),
				"ProjectToDate": this.getView().byId("id_prj_date").getDateValue(),
				"BlitzDate": this.getView().byId("id_blitz_date").getDateValue(),
				"BlitzStatus": this.getView().byId("id_blitz_stat").getValue(),
				"EngModel": this.getView().byId("id_eng_mod").getValue(),
				"Comments": this.getView().byId("id_comments").getValue()
					/*	"NPIEngModelSet":updatedEngtableData,
						"to_part":updatedPartstableData*/

				/*"NPIEngModelSet": [{
						"ProgramId": "TEST1",
						"EngModel": "ENG4",
						"Descr": "test"
					}]*/
				/*	"to_part": [{
						"part_number": "test",
						"createdby": "test1"
					}]*/
			};
			this.oUpdateModel.update("/NPIProgramSet(ProgramId='" + pgmid + "',SerialNumber='" + sno + "')", oHeaderData, {
				success: function (oData) {
					/*sap.m.MessageBox.success(this.getView().getModel("i18n").getResourceBundle().getText("updatesuccessText"));*/
					//	sap.m.MessageBox.success("updatesuccessText");
					MessageToast.show("Successfully Updated");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("Main", true);
					//	this._setViewBusy(false);
				}.bind(this),
				error: function (err) {
					MessageBox.error("updateErrorText");
				}
			});
		},
		/*
		 *@memberOf NPI.NPI_UI5.controller.Detail
		 */
		GoToSource: function (oEvent) {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			// Go one screen back if you find a Hash
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			}
			// If you do not find a correct Hash, go to the Source screen using default router;
			else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Main", true);
			}
		}
	});
});