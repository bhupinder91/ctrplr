sap.ui.define([
	"NPI/NPI_UI5/test/unit/controller/Main.controller"
], function () {
	"use strict";
});